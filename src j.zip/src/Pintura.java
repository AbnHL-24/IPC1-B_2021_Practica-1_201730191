public class Pintura {
    //Dejar pendiendte, desarrollar logica y si funciona tipoMotor y tipoLlanta entonces aplicar misma logica a pintura.
}